import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import com.example.aula4.R;

public class Main extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText Nome = findViewById(R.id.editTextText);
        EditText Sobrenome = findViewById(R.id.editTextText2);
        EditText Telefone = findViewById(R.id.editTextText3);

        Button btnCancelar = findViewById(R.id.button);
        Button btnSalvar = findViewById(R.id.button2);
    }
}